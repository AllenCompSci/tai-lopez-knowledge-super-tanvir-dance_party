package picross;

/**
 * Created by mario on 1/13/2017.
 */
public class Constants {
	public static double e = 2.71828182845904523536028747135266249775724709369995;
	public static double pi = 3.14159265358979323846264338327950288419716939937510;
}
