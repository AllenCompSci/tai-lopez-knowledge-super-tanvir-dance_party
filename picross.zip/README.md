# picross
My Picross project. Includes main menus and random puzzles of variable sizes; ALL puzzles are 100% solvable!

FEATURES:
- Random puzzles - Play a puzzle of any size, from 1x1 to 25x25.
- Puzzle creator - Create your own puzzles! These must be uniquely solvable.

TODO
- Comparing your scores to those of other players
- Online repository for puzzles
- Other modes of control (i.e keyboard controls)
- Better looking graphics - better button highlighting, custom textures and animations
- More efficient system for generating puzzles, the current system is not optimal
